<?php 
/* Template Name: Blog */
?>
<?php get_header() ?>

<section>
	<div class="container-centralizado">
		<h2>BLOG</h2>
	</div>
</section>
<section class="blog">
	<div class="container-centralizado">
		<div class="posts">
			<?php query_posts( array(
				'posts_per_page' => 5,
				'paged'          => $paged,
				)); ?>	

				<?php if( have_posts() ): while ( have_posts() ) : the_post(); ?>
					<div id="corpo-posts">
						<a href="<?php the_permalink() ?>" >
							<div class="thumbnail-destaque">
								<div class="capa-home-post">
									<?php the_post_thumbnail(); ?>
								</div>
							</div>
							<a href="<?php the_permalink() ?>" >
								<h1 class="titulo-thumb-cat"><?php the_title(); ?></h1>
							</a>
							<div class="descricao-post"><?php the_excerpt(); ?></div>
						</a>
					</div>
				<?php endwhile; ?>
				<div class="box-btns-paginacao">
					<div class="btn-anterior">
						<span class="botao">
							<?php
						// get_next_posts_link() usage with max_num_pages
							echo get_next_posts_link( 'Próxima', $the_query->max_num_pages );
							?>
						</span>
					</div>
					<div class="btn-foward">
						<span class="botao">
							<?php
						// get_next_posts_link() usage with max_num_pages
							echo get_previous_posts_link( 'Anterior' );
							?>
						</span>
					</div>
				</div>

			<?php else : ?>
				<p><?php __('No News'); ?></p>
			<?php endif; ?>
		</div>
	</div>

</section>
<?php get_footer() ?>